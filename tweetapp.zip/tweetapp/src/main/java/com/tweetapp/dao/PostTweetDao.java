package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.tweetapp.DBConnection;
import com.tweetapp.model.Tweet;



public class PostTweetDao {

	
	
	public boolean postATweet(Tweet tweetObj) {
       
        boolean result = false;
        try
        {
            String sql = "Insert into tweettable VALUES(?, ?)";
            Connection connection = DBConnection.getConnection();
            
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            stmt.setString(1, tweetObj.getUsername());
            stmt.setString(2, tweetObj.getTweet());
            
            
            int inserted = stmt.executeUpdate();
            
            result = inserted >=1;
            DBConnection.disconnect(connection);
        } catch(Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}

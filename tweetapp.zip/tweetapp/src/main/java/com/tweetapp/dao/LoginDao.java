package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tweetapp.DBConnection;



public class LoginDao {

	
	
	 public boolean loginUser(String emailid, String password) {
	       
	        boolean result = false;
	        try
	        {
	            String sql = "SELECT * from user WHERE emailid=? and password=?";
	            Connection connection = DBConnection.getConnection();
	            
	            PreparedStatement stmt = connection.prepareStatement(sql);
	            
	            stmt.setString(1, emailid);
	            stmt.setString(2, password);
	            
	            ResultSet rs = stmt.executeQuery();
	            
	            
	            if( rs.next()){
	                result = true;
	           } else {
	               result = false;
	           }
	         
	            
	           
	            DBConnection.disconnect(connection);
	        } catch(Exception e) {
	            e.printStackTrace();
	        }
	        return result;
	    }
}

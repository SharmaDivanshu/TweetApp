package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tweetapp.DBConnection;



public class ResetPasswordDao {

	
	 public boolean resetPasswordDao(String emailid, String newPassword) {
	      
	        boolean result = false;
	        try
	        {
	            String sql = "SELECT * from user WHERE emailid=?";
	            Connection connection = DBConnection.getConnection();
	            
	            PreparedStatement stmt = connection.prepareStatement(sql);
	            
	            stmt.setString(1, emailid);
	             
	            ResultSet rs = stmt.executeQuery();
	          
	            if( rs.next()){
	               
	                String updateSql = "UPDATE user SET password =? WHERE emailid =?";
	               
	                PreparedStatement stmt1 = connection.prepareStatement(updateSql);
	              
	                stmt1.setString(1, newPassword);
		            stmt1.setString(2, emailid);
		            
	                int inserted = stmt1.executeUpdate();
	                
	                result = inserted >=1;
	           } else {
	               result = false;
	           }
	           
	            DBConnection.disconnect(connection);
	        } catch(Exception e) {
	            e.printStackTrace();
	        }
	        return result;
	    }
	
	
}

package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;

import com.tweetapp.DBConnection;
import com.tweetapp.model.Tweet;



public class ViewTweetsDao {

	public ArrayList<Tweet> getTweetsFromDB(String username) {

		ArrayList<Tweet> al = new ArrayList<Tweet>();
		try {
			String sql = "SELECT * from tweettable WHERE username=?";
			Connection connection = DBConnection.getConnection();

			PreparedStatement stmt = connection.prepareStatement(sql);

			stmt.setString(1, username);

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Tweet tweet = new Tweet();
				tweet.setTweet(rs.getString(2));
				tweet.setUsername(rs.getString(1));

				al.add(tweet);

			}

			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		return al;
	}

	public ArrayList<Tweet> getAllUserTweetsFromDB() {

		ArrayList<Tweet> all = new ArrayList<Tweet>();
		try {
			String sql = "SELECT * from tweettable";
			Connection connection = DBConnection.getConnection();

			PreparedStatement stmt = connection.prepareStatement(sql);

			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
			
				Tweet tweet = new Tweet();
				tweet.setTweet(rs.getString(2));
				tweet.setUsername(rs.getString(1));

				all.add(tweet);

			}

			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		return all;
	}

	public HashSet<String> getAllUserListFromDB() {
		HashSet<String> hs=new HashSet<String>();
		try {
			String sql = "SELECT * from user";
			Connection connection = DBConnection.getConnection();

			PreparedStatement stmt = connection.prepareStatement(sql);

			ResultSet rs = stmt.executeQuery();

			
			while (rs.next()) {
				
		     hs.add(rs.getString(4));

			} 
			DBConnection.disconnect(connection);
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		return hs;
	}

}

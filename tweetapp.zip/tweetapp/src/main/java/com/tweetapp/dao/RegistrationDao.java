package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.tweetapp.DBConnection;
import com.tweetapp.model.Register;



public class RegistrationDao {

	 public boolean insertUser(Register user) {
	        
	        boolean result = false;
	        try
	        {
	        	String sql = "select * from user where emailid = ?";
	            Connection connection = DBConnection.getConnection();
	            
	            PreparedStatement st = connection.prepareStatement(sql);
	            
	            st.setString(1, user.getEmailId());
	            ResultSet rs = st.executeQuery();
	        	
	            if(rs.next()){
	                System.out.println("user already exist in database");
	           }
	           else{
	               
	            String insertSql = "Insert into user VALUES(?, ?, ?, ?, ?, ?)";
	            
	            
	            PreparedStatement stmt = connection.prepareStatement(insertSql);
	            
	            
	            stmt.setString(1, user.getFirstName());
	            stmt.setString(2, user.getLastName());
	            stmt.setString(3, user.getGender());
	            stmt.setString(4, user.getEmailId());
	            stmt.setString(5, user.getDob());
	            stmt.setString(6, user.getPassword());
	            
	            int inserted = stmt.executeUpdate();
	            
	            result = inserted >=1;
	            DBConnection.disconnect(connection);
	            
	           }
	        } catch(Exception e) {
	            e.printStackTrace();
	        }
	        return result;
	    }
}

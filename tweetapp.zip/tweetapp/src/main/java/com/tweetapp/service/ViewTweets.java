package com.tweetapp.service;

import java.util.ArrayList;
import java.util.HashSet;

import com.tweetapp.dao.ViewTweetsDao;
import com.tweetapp.model.Tweet;



public class ViewTweets {

	public ArrayList<Tweet> getMyTweets(String username) {
		
		
		ViewTweetsDao vtDao=new ViewTweetsDao();
		
		ArrayList<Tweet> al = vtDao.getTweetsFromDB(username);
		
		
		
		return al;
	}

	public ArrayList<Tweet> getAllUserTweets() {
		
     ViewTweetsDao vtDao=new ViewTweetsDao();
		
		ArrayList<Tweet> al = vtDao.getAllUserTweetsFromDB();
		
		
		
		return al;
	}

	public HashSet<String> getAllUserList() {
		 ViewTweetsDao vtDao=new ViewTweetsDao();
			
		 HashSet<String> al = vtDao.getAllUserListFromDB();
			
			
			
			return al;
	}
	
}

package com.tweetapp.service;

import java.util.Scanner;

import com.tweetapp.dao.PostTweetDao;
import com.tweetapp.model.Tweet;



public class PostTweet {

	Scanner scanner = new Scanner(System.in);
	
	public void postTweet(String username) {
		
		
		    System.out.println("############# POST TWEET #############");
	        System.out.print("Post a  Tweet => ");
	        String tweet = scanner.nextLine();
		
		
		Tweet tweetObj=new Tweet();
		tweetObj.setTweet(tweet);
		tweetObj.setUsername(username);
		
		PostTweetDao ptDao=new PostTweetDao();
		if(ptDao.postATweet(tweetObj)) {
			
			System.out.println("Tweet Posted Successfully.....");
			Menu menu =new Menu();
			menu.getMenu(username);
			
			
		}else {
			
			
			System.out.println("Tweet Posted Failed....");
			
		}
		
	}
}

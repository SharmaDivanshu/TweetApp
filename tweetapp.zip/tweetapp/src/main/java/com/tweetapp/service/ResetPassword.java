package com.tweetapp.service;

import java.util.Scanner;

import com.tweetapp.dao.ResetPasswordDao;



public class ResetPassword {

	Scanner scanner = new Scanner(System.in);
	
	public void resetPassword() {
		
		
		System.out.println("############# To reset Password username is required #############");
		
		System.out.println("Enter user name => ");
		String userName = scanner.nextLine();

		System.out.print("Enter New password => ");
		String newPassword = scanner.nextLine();
		
		ResetPasswordDao resetPassDao=new ResetPasswordDao();
		
		if(resetPassDao.resetPasswordDao(userName, newPassword)) {
			
			System.out.println("Password reset successfully - Please Login");
			LoginService login=new LoginService();
        	login.getLogin();
        	
		}else {
			
			System.out.println(" Password reset failed...");
			
			
		}
		
		
		
	}
	
	
	
}

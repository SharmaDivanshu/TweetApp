package com.tweetapp.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

import com.tweetapp.App;
import com.tweetapp.model.Tweet;



public class Menu {

	Scanner scanner = new Scanner(System.in);
	
	public void getMenu(String userName) {
		
		System.out.println("### Menu Page ###");
		System.out.println("Your choices:");
		System.out.println("1. Post a tweet");
		System.out.println("2. Show my tweet");
		System.out.println("3. Show User list");
		System.out.println("4. Show all tweets");
		System.out.println("5. Logout");

		System.out.println("Enter your choice :");
		
        String choice = scanner.nextLine();
        
        switch(choice){  
       
        case "1": 
        	PostTweet pt = new PostTweet();
			pt.postTweet(userName); 
        case "2": 
        	ViewTweets vt = new ViewTweets();
			ArrayList<Tweet> al = vt.getMyTweets(userName);
	
			if (al.isEmpty()) {
				System.out.println("Record not present in DB....");
				 getMenu(userName);
			} else {
				System.out.println("### Below are the List of my ALL Tweet ###");
				
				al.forEach((s) -> {
					System.out.println(s.getTweet());
				});
				
				getMenu(userName);
			}
        case "3": 
            ViewTweets vtt = new ViewTweets();
			HashSet<String> set = vtt.getAllUserList();
			
			if (set.isEmpty()) {
				System.out.println("User Record not present in DB....");
				getMenu(userName);
			} else {
				System.out.println("### Below are the List of  ALL THE USERS ###");
				
				set.forEach((s) -> {
					System.out.println(s);
				});
    
				
				getMenu(userName);
			}
        case "4": 
        	ViewTweets vtweet = new ViewTweets();
			ArrayList<Tweet> alist = vtweet.getAllUserTweets();

			if (alist.isEmpty()) {
				System.out.println("Record not found in DB...");
				getMenu(userName);
				
			} else {
				
				System.out.println("### Below are the Tweets for ALL THE USERS ###");
				alist.forEach(p -> System.out.println(p.getTweet()));
				
				
				getMenu(userName);
				
			}
        case "5": 
        	App.main(null);
        default:
        	System.out.println("Invalid Choice, Please select a valid choice");
        	
        	getMenu(userName);
        }  
		

	}
	
	
}

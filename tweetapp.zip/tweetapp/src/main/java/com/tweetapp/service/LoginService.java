package com.tweetapp.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Optional;
import java.util.Scanner;
import java.util.Set;

import com.tweetapp.App;
import com.tweetapp.dao.LoginDao;



public class LoginService {

	Scanner scanner = new Scanner(System.in);

	public void getLogin() {

		System.out.println("############# LOGIN #############");

		System.out.println("Enter user name => ");
		String userName1 = scanner.nextLine();

		System.out.print("Enter password => ");
		String password1 = scanner.nextLine();

		LoginDao ls = new LoginDao();
		if (ls.loginUser(userName1, password1)) {
			
			System.out.println(" User successfully logged-in...");
			
			Menu menu = new Menu();
			menu.getMenu(userName1);

	} else {
			System.out.println("Incorrect Credentials..... Please Try again");
			getLogin();

		}

	}
}
